package com.bproject.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSourceConfig {
}
